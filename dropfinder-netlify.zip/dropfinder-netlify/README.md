# DropFinder

Trova prodotti da dropshipping in crescita (Amazon.it Movers & Shakers + Google Trends Italia) con link ai fornitori. Si aggiorna da solo.

## Deploy su Netlify
1. Carica questa cartella su GitHub.
2. Su Netlify: Add new site, Import from Git, scegli il repository.
3. Lascia i valori predefiniti (li legge da netlify.toml) e premi Deploy.

## Struttura
- index.html: pagina
- netlify/functions/products.js: funzione che legge i dati
- netlify.toml: configurazione
