// Funzione serverless Netlify: legge Amazon.it Movers & Shakers e Google Trends a ogni richiesta (cache CDN 10 min)
const UA = { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36", "Accept-Language": "it-IT,it;q=0.9" };
let state = { products: [], trends: [], updated: null, status: "Avvio…", log: [] };

const num = s => parseFloat(String(s).replace(/\./g, "").replace(",", "."));
const dec = s => s.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;|&#x27;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">");
async function get(url) {
  const r = await fetch(url, { headers: UA, signal: AbortSignal.timeout(6000) });
  if (!r.ok) throw new Error(url + " -> HTTP " + r.status);
  return r.text();
}
function links(q) {
  const e = encodeURIComponent(q);
  return {
    aliexpress: "https://www.aliexpress.com/wholesale?SearchText=" + e,
    cj: "https://cjdropshipping.com/search/" + e + ".html",
    alibaba: "https://www.alibaba.com/trade/search?SearchText=" + e,
    trends: "https://trends.google.com/trends/explore?geo=IT&q=" + e,
    meta: "https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=IT&q=" + e,
    tiktok: "https://www.tiktok.com/search?q=" + e,
  };
}
// Titolo lungo di Amazon -> termine di ricerca breve per i fornitori
const short = t => t.replace(/\(.*?\)|\[.*?\]/g, "").split(/[,|\-–:]/)[0].trim().split(/\s+/).slice(0, 5).join(" ");

async function moversPage(path) {
  const html = await get("https://www.amazon.it/gp/movers-and-shakers/" + path);
  const out = [];
  const cat = (html.match(/<title>[^<]*?:\s*([^<:]+?)\s*<\/title>/) || [])[1] || "Generale";
  for (const b of html.split("p13n-sc-uncoverable-faceout").slice(1)) {
    const asin = (b.match(/\/dp\/([A-Z0-9]{10})/) || [])[1];
    const title = (b.match(/alt="([^"]{6,})"/) || [])[1];
    if (!asin || !title) continue;
    const pr = (b.match(/([\d.]+,\d{2})\s*(?:€|&euro;)/) || [])[1] || (b.match(/€\s*([\d.]+,\d{2})/) || [])[1];
    const pc = (b.match(/([\d.]+)%/) || [])[1];
    const rank = (b.match(/#\s*(\d+)/) || [])[1];
    out.push({ asin, name: dec(title), price: pr ? num(pr) : null, growth: pc ? num(pc) : 0, rank: rank ? +rank : 99, category: dec(cat).replace(/Amazon\.it:?\s*/i, "").trim() });
  }
  return out;
}
async function refresh() {
  const log = [];
  try {
    const home = await get("https://www.amazon.it/gp/movers-and-shakers/");
    const cats = [...new Set([...home.matchAll(/\/gp\/movers-and-shakers\/([a-z0-9-]+)[/?"]/g)].map(m => m[1]))].filter(c => c !== "ref").slice(0, 8);
    const pages = await Promise.allSettled(["", ...cats].map(c => moversPage(c ? c + "/" : "")));
    const seen = new Map();
    pages.forEach((p, i) => {
      if (p.status !== "fulfilled") return log.push("Pagina saltata: " + p.reason.message);
      for (const x of p.value) if (!seen.has(x.asin)) seen.set(x.asin, x);
    });
    const list = [...seen.values()].map(x => {
      const q = short(x.name), cost = x.price ? Math.round(x.price * 0.35 * 100) / 100 : null; // stima costo fornitore ~35% del prezzo Amazon
      const score = Math.max(1, Math.min(100, Math.round(Math.log10(1 + x.growth) * 28 + (100 - x.rank) * 0.2 + (x.price && x.price >= 15 && x.price <= 70 ? 12 : 0))));
      return { ...x, term: q, score, est_cost: cost, margin: cost ? Math.round((1 - cost / x.price) * 100) : null, url: "https://www.amazon.it/dp/" + x.asin, links: links(q) };
    }).sort((a, b) => b.score - a.score).slice(0, 60);
    if (list.length) state.products = list; else log.push("Amazon non ha restituito prodotti (blocco o layout cambiato).");
  } catch (e) { log.push("Amazon: " + e.message); }
  try {
    const xml = await get("https://trends.google.com/trending/rss?geo=IT");
    state.trends = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].slice(0, 20).map(m => {
      const t = dec((m[1].match(/<title>([^<]+)/) || [])[1] || ""), tr = (m[1].match(/approx_traffic>([^<]+)/) || [])[1] || "";
      return { name: t, traffic: tr, links: links(t) };
    }).filter(t => t.name);
  } catch (e) { log.push("Google Trends: " + e.message); }
  state.updated = new Date().toISOString(); state.log = log;
  state.status = log.length ? "Aggiornato con avvisi" : "Tutto ok";
  console.log(state.updated, state.products.length, "prodotti", log);
}

exports.handler = async () => {
  state = { products: [], trends: [], updated: null, status: "Avvio…", log: [] };
  await refresh();
  return { statusCode: 200, headers: { "Content-Type": "application/json", "Netlify-CDN-Cache-Control": "public, s-maxage=600, stale-while-revalidate=1200", "Cache-Control": "public, max-age=0, must-revalidate" }, body: JSON.stringify(state) };
};
